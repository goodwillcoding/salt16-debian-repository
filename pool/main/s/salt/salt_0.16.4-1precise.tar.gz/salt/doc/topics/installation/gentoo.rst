======
Gentoo
======

Salt can be easily installed on Gentoo via Portage:

.. code-block:: bash

    emerge app-admin/salt

Post-installation tasks
=======================

Now go to the :doc:`Configuring Salt</topics/configuration>` page.

.. _GitHub downloads: https://github.com/saltstack/salt/downloads
