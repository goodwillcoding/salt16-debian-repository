.. _all-salt.wheel:

==================================
Full list of builtin wheel modules
==================================

.. currentmodule:: salt.wheel

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    config
    file_roots
    key
    pillar_roots
