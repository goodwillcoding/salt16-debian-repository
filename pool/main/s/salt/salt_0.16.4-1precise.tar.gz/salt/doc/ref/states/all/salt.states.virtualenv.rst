======================
salt.states.virtualenv
======================

.. automodule:: salt.states.virtualenv
    :members:
    :exclude-members: manage
