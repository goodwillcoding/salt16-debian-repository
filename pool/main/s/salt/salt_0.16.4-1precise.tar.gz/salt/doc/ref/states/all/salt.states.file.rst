================
salt.states.file
================

.. automodule:: salt.states.file
    :members: