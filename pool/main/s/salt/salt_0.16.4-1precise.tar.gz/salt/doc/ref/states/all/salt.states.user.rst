================
salt.states.user
================

.. automodule:: salt.states.user
    :members: