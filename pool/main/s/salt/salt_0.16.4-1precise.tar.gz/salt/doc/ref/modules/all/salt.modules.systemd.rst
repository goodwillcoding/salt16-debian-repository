====================
salt.modules.systemd
====================

.. automodule:: salt.modules.systemd
    :members: