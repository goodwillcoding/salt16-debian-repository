==========================
salt.states.postgres_group
==========================

.. automodule:: salt.states.postgres_group
    :members:
