=======================
salt.modules.virtualenv
=======================

.. automodule:: salt.modules.virtualenv
    :members: