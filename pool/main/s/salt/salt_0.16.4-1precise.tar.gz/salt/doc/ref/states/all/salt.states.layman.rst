==================
salt.states.layman
==================

.. automodule:: salt.states.layman
    :members:
