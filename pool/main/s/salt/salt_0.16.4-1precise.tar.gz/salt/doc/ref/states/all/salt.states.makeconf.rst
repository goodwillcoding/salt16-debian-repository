====================
salt.states.makeconf
====================

.. automodule:: salt.states.makeconf
    :members: