=================
salt.modules.file
=================

.. automodule:: salt.modules.file
    :members: