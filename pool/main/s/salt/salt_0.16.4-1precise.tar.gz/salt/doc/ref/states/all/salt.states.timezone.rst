====================
salt.states.timezone
====================

.. automodule:: salt.states.timezone
    :members: