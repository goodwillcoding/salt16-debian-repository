=====================
salt.modules.rabbitmq
=====================

.. automodule:: salt.modules.rabbitmq
    :members: