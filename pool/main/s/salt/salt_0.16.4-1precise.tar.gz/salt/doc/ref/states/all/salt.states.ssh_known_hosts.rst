===========================
salt.states.ssh_known_hosts
===========================

.. automodule:: salt.states.ssh_known_hosts
    :members:
