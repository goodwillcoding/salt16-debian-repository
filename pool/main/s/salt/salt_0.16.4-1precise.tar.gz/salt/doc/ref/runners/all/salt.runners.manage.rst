===================
salt.runners.manage
===================

.. automodule:: salt.runners.manage
    :members: