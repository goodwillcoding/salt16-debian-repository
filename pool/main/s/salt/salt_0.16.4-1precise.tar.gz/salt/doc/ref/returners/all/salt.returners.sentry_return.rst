============================
salt.returners.sentry_return
============================

.. automodule:: salt.returners.sentry_return
    :members: