===================
salt.modules.yumpkg
===================

.. versionadded:: 0.9.4
    This module replaces the "yum" module in previous releases. It is backward
    compatible and uses the native yum Python interface instead of the CLI
    interface.

.. automodule:: salt.modules.yumpkg
    :members:
    :exclude-members: available_version
