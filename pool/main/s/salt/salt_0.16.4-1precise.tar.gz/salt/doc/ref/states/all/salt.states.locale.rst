==================
salt.states.locale
==================

.. automodule:: salt.states.locale
    :members: