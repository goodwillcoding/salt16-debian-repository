===============================
salt.returners.cassandra_return
===============================

.. automodule:: salt.returners.cassandra_return
    :members: