=========================
salt.modules.win_groupadd
=========================

.. automodule:: salt.modules.win_groupadd
    :members:
