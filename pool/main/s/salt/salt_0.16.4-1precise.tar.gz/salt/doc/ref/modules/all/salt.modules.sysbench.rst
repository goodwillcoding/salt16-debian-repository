=====================
salt.modules.sysbench
=====================

.. automodule:: salt.modules.sysbench
    :members: