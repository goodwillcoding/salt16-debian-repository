====================
salt.pillar.puppet
====================

.. automodule:: salt.pillar.puppet
    :members:
