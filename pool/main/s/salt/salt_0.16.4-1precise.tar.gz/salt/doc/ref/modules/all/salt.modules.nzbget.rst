===================
salt.modules.nzbget
===================

.. automodule:: salt.modules.nzbget
    :members: