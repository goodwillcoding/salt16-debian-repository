================
salt.modules.git
================

.. automodule:: salt.modules.git
    :members: