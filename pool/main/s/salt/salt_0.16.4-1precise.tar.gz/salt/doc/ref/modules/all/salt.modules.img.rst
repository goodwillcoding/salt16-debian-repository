================
salt.modules.img
================

.. automodule:: salt.modules.img
    :members: