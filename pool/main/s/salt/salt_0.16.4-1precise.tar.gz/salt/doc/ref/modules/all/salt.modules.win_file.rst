=====================
salt.modules.win_file
=====================

.. automodule:: salt.modules.win_file
    :members: