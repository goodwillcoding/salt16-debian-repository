==================
salt.states.module
==================

.. automodule:: salt.states.module
    :members: