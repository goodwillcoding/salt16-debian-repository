====================
salt.modules.yumpkg5
====================

.. automodule:: salt.modules.yumpkg5
    :members:
    :exclude-members: available_version
