==========================
salt.output.overstatestage
==========================

.. automodule:: salt.output.overstatestage
    :members: