===============
salt.states.pip
===============

.. automodule:: salt.states.pip
    :members: