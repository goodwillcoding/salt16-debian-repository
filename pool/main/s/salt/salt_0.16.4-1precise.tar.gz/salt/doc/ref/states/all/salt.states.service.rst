===================
salt.states.service
===================

.. automodule:: salt.states.service
    :members: