=================
salt.pillar.hiera
=================

.. automodule:: salt.pillar.hiera
    :members:
