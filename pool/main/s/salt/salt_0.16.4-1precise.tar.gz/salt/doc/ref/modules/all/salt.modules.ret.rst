================
salt.modules.ret
================

.. automodule:: salt.modules.ret
    :members: