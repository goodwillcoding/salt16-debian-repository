=======================
salt.modules.win_system
=======================

.. automodule:: salt.modules.win_system
    :members: