================
salt.modules.apt
================

.. automodule:: salt.modules.apt
    :members:
    :exclude-members: available_version
