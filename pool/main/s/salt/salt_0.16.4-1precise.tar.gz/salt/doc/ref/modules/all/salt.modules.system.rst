===================
salt.modules.system
===================

.. automodule:: salt.modules.system
    :members: