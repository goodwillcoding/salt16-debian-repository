==================
salt.modules.pkgng
==================

.. automodule:: salt.modules.pkgng
    :members:
    :exclude-members: available_version
