===============
salt.states.lvm
===============

.. automodule:: salt.states.lvm
    :members:
