========================
salt.modules.win_useradd
========================

.. automodule:: salt.modules.win_useradd
    :members: