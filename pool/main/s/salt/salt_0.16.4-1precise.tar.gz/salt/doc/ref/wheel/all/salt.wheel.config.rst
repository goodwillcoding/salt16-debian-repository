=================
salt.wheel.config
=================

.. automodule:: salt.wheel.config
    :members: