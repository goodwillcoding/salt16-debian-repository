=============================
salt.states.postgres_database
=============================

.. automodule:: salt.states.postgres_database
    :members: